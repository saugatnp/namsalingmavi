<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $title; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $titles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h1 style="text-align: center; margin-top:50px;"><?php echo e($titles->title); ?> </h1>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="gallery">
        <?php $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <div class="col-md-4 mb-4">
                    <div class="card">
                        
                        
                        <img src="<?php echo e(asset('storage/images/'.$data->photo)); ?>" alt="<?php echo e($titles->title); ?>" class="card-img" >
                    </div>
                </div>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/namsalin/public_html/namsalingmavi/resources/views/pages/images.blade.php ENDPATH**/ ?>