<?php $__env->startSection('content'); ?>
        <div class="exam-routine">
                
                <div class="col-md-8">
                        <?php $__currentLoopData = $routine; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h1> <?php echo e($data->title); ?> </h1>
                        <p> <?php echo $data->value; ?>

                        </p>
                        <img src="<?php echo e(asset('storage/images/'.$data->image)); ?>" width="100%">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/namsalin/public_html/namsalingmavi/resources/views/pages/academics/examroutine.blade.php ENDPATH**/ ?>