</div>
		<footer class="footer-distributed">

			<div class="footer-left">

				<h3 class="text-color" >Namsaling High School</h3>
                <br/>
				<p class="footer-links ">
					<a href="#" class="text-color footer-company-about">Home</a>
					·
					<a href="#" class="text-color footer-company-about">Academics</a>
					·
					<a href="#" class="text-color footer-company-about">Gallery</a>
					·
					<a href="#" class="text-color footer-company-about">Library</a>
					·
					<a href="#" class="text-color footer-company-about">About Us</a>
					·
					<a href="#" class="text-color footer-company-about">Contact Us</a>
				</p>

				<p class="footer-company-about text-color">Copyright © 2021 Namsaling high School.</p>
			</div>

			<div class="footer-center text-color">

				<div class="footer-link">
					<i class="fa fa-map-marker"></i>
					<p><span>Maijogmai-3</span> Ilam, Nepal</p>
				</div>

				<div class="footer-link">
					<i class="fa fa-phone"></i>
					<p>027-1234567</p>
				</div>

				<div class="footer-link ">
					<i class="fa fa-envelope"></i>
					<p><a href="mailto:support@company.com" style="color: #17252a;">info@namsalingmavi.edu.np</a></p>
				</div>

			</div>

			<div class="footer-right text-color">
                <h4>About the institution</h4>
				<p class="footer-company-about">
                <br/>
					Namsaling high school is an educational institution located in Maijogmai-3 Ilam.Is is a government designated national school.
				</p>

				<div class="footer-icons">

					<a href="#"><i class="fa fa-facebook"></i></a>
					<a href="#"><i class="fa fa-twitter"></i></a>
					<a href="#"><i class="fa fa-youtube"></i></a>

				</div>

			</div>

		</footer>

	</body>

</html><?php /**PATH /var/www/html/ava/namsalingmavi/resources/views/includes/footer.blade.php ENDPATH**/ ?>