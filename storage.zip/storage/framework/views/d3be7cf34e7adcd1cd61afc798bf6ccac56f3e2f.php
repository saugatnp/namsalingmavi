		<footer class="footer-distributed">
			<div class="footer-left text-color">
				<h3 class="text-color" >Namsaling High School</h3>
                <br/>
				<p class="footer-links ">
					<a href="/index" class="text-color footer-company-about">Home</a>
					·
					<a href="/academics/booklist" class="text-color footer-company-about">Academics</a>
					·
					<a href="/gallery" class="text-color footer-company-about">Gallery</a>
					·
					<a href="/library" class="text-color footer-company-about">Library</a>
					·
					<a href="aboutus/bot" class="text-color footer-company-about">About Us</a>
					·
					<a href="/contactus" class="text-color footer-company-about">Contact Us</a>
				</p>
				<p class="footer-company-about text-color">Copyright © 2021 Namsaling high School.</p>
			</div>
			<div class="footer-center text-color">
				<div class="footer-link">
					<i class="fa fa-map-marker fa-icon"></i>
					<p class="text-color"><span>Maijogmai-3</span> Ilam, Nepal</p>
				</div>

				<div class="footer-link">
					<i class="fa fa-phone fa-icon"></i>
					<p class="text-color">9842646517</p>
				</div>

				<div class="footer-link ">
					<i class="fa fa-envelope fa-icon"></i>
					<p ><a href="mailto:namsalingmavi@gmail.com" class="text-color">namsalingmavi@gmail.com</a></p>
				</div>

			</div>

			<div class="footer-right text-color">
                <h4>About the institution</h4>
				<p class="footer-company-about">
                <br/>
					Namsaling high school is an educational institution located in Maijogmai-3 Ilam.Is is a government designated national school.
				</p>

				<div class="footer-icons">

					<center><a href="https://www.facebook.com/namsalinghighschool.ilam/"><i class="fa fa-facebook"></i></a>
					<a href="https://www.youtube.com/channel/UCftoOYsA5DeB_kcxeHbz1uw"><i class="fa fa-youtube"></i></a></center>
					

				</div>

			</div>

		</footer>

	</body>

</html><?php /**PATH /home/namsalin/public_html/namsalingmavi/resources/views/includes/footer.blade.php ENDPATH**/ ?>