<?php $__env->startSection('content'); ?>

    <h1 style="text-align: center; margin-top:50px;">Gallery </h1>
    <div class="gallery">
        
        <?php $__currentLoopData = $images->unique('album_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $album; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($data->id == $img->album_id): ?>
                    <tr>
                        <div class="col-md-4 mb-3">
                            <div class="card">
                                
                                <a href="/gallery/images/<?php echo e($data->id); ?>" class="card-img"><img src="<?php echo e(asset('/storage/images/'.$img->photo)); ?>"
                                        alt="<?php echo e($data->title); ?>" class="card-img"></a>
                                <div class="card-body">
                                    <div class="card-title">
                                        <th><?php echo e($data->title); ?></th>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/namsalin/public_html/namsalingmavi/resources/views/pages/gallery.blade.php ENDPATH**/ ?>