<?php $__env->startSection('content'); ?>
        <h1>This is exam result page</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/namsalin/public_html/namsalingmavi/resources/views/pages/academics/examresult.blade.php ENDPATH**/ ?>