<?php $__env->startSection('content'); ?>

    <div class="mainback">
        <h1>Home</h1>
        <div class="back">
            <table cellpadding="0" style="width:100%;border: 1px solid black;">
                <tr>
                    <th>S.N.</th>
                    <th>Title</th>
                    <th>Action</th>
                </tr>
                <tr>
                    
                    <?php $__currentLoopData = $crouselone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $croone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td></td>
                        <td><?php echo e($croone->title); ?></td>
                        <td><a class="btn btn-success button5" href="/index/<?php echo e($croone->id); ?>/edit"><i
                                    class="fa fa-edit"></i>&nbsp;Edit</a></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
                <tr>
                    <?php $__currentLoopData = $crouseltwo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crotwo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td></td>
                        <td><?php echo e($crotwo->title); ?></td>
                        <td><a class="btn btn-success button5" href="/index/<?php echo e($crotwo->id); ?>/edit"><i
                                    class="fa fa-edit"></i>&nbsp;Edit</a></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
                <tr>
                    <?php $__currentLoopData = $crouselthree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crothree): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td></td>
                        <td><?php echo e($crothree->title); ?></td>
                        <td> <a class="btn btn-success button5" href="/index/<?php echo e($crothree->id); ?>/edit"><i
                                    class="fa fa-edit"></i>&nbsp;Edit</a></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
                <tr>
                    <?php $__currentLoopData = $principalmsgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pmsg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td></td>
                        <td><?php echo e($pmsg->title); ?></td>
                        <td> <a class="btn btn-success button5" href="/index/<?php echo e($pmsg->id); ?>/edit"><i
                                    class="fa fa-edit"></i>&nbsp;Edit</a></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
                <tr>
                    <?php $__currentLoopData = $sectionone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td></td>
                        <td><?php echo e($secone->title); ?></td>
                        <td> <a class="btn btn-success button5" href="/index/<?php echo e($secone->id); ?>/edit"><i
                                    class="fa fa-edit"></i>&nbsp;Edit</a></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
                <tr>
                    <?php $__currentLoopData = $sectiontwo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sectwo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td></td>
                        <td><?php echo e($sectwo->title); ?></td>
                        <td><a class="btn btn-success button5" href="/index/<?php echo e($sectwo->id); ?>/edit"><i
                                    class="fa fa-edit"></i>&nbsp;Edit</a></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
                <tr>

                    <?php $__currentLoopData = $sectionthree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secthree): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td></td>
                        <td><?php echo e($secthree->title); ?></td>
                        <td><a class="btn btn-success button5" href="/index/<?php echo e($secthree->id); ?>/edit"><i
                                    class="fa fa-edit"></i>&nbsp;Edit</a></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
                <tr>
                    <?php $__currentLoopData = $recentevent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rctevt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td></td>
                        <td> <?php echo e($rctevt->title); ?></td>
                        <td><a class="btn btn-success button5" href="/index/<?php echo e($rctevt->id); ?>/edit"><i
                                    class="fa fa-edit"></i>&nbsp;Edit</a></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
                <tr>
                    <?php $__currentLoopData = $recenteventtwo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td></td>
                    <td><?php echo e($data->title); ?></td>
                    <td><a class="btn btn-success button5" href="/index/<?php echo e($data->id); ?>/edit"><i
                        class="fa fa-edit"></i>&nbsp;Edit</a></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>

            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/namsalin/public_html/namsalingmavi/resources/views/backends/home.blade.php ENDPATH**/ ?>