<?php $__env->startSection('content'); ?>
        <h1>This is academic level page</h1>
this is aca
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/namsalingmavi/resources/views/pages/academicslevel.blade.php ENDPATH**/ ?>