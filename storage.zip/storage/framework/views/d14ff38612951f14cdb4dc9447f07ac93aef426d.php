<?php $__env->startSection('content'); ?>
    <h1 style="text-align:center;"><strong> Notice Board</strong></h1>
    <center>
        <div class="notice">
            <?php $__currentLoopData = $notice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="contents">
                    <p><?php echo e($data->title); ?></p>
                    <p class="dtt"><?php echo e(date('Y/m/d', strtotime($data->created_at))); ?></p>
                    <a href="/notice/viewdetails/<?php echo e($data->id); ?>"><button class="btn btn-primary">View Details</button></a>
                </div>
                <hr />
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </center>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/namsalin/public_html/namsalingmavi/resources/views/pages/notice.blade.php ENDPATH**/ ?>