<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>library</title>
    </head>
    <body >
        <h1>This is library page</h1>
    </body>
</html>
<?php /**PATH /var/www/html/namsalingmavi/resources/views/pages/library.blade.php ENDPATH**/ ?>