<?php $__env->startSection('content'); ?>
        <h1 style="text-align: center; margin-top:50px;">Gallery </h1>
        <div class="gallery">
                
                <div class="col-md-4 mb-4">
                        <div class="card">     
                                <img src="https://bnks.edu.np/uploads/gallery/gallery-20200317041239-397.JPG" alt="School Day 2020" class="c0139 c0145 card-img">
                                <div class="card-body">
                                        <div class="c0140 c0146 card-title">
                                                School Day 2020
                                        </div>
                                </div>
                        </div>
                </div>
                <div class="col-md-4 mb-4">
                        <div class="card">     
                                <img src="https://bnks.edu.np/uploads/gallery/gallery-20200317041239-397.JPG" alt="School Day 2020" class="c0139 c0145 card-img">
                                <div class="card-body">
                                        <div class="c0140 c0146 card-title">
                                                School Day 2020
                                        </div>
                                </div>
                        </div>
                </div>
                <div class="col-md-4 mb-4">
                        <div class="card">     
                                <img src="https://bnks.edu.np/uploads/gallery/gallery-20200317041239-397.JPG" alt="School Day 2020" class="c0139 c0145 card-img">
                                <div class="card-body">
                                        <div class="c0140 c0146 card-title">
                                                School Day 2020
                                        </div>
                                </div>
                        </div>
                </div>
                <div class="col-md-4 mb-4">
                        <div class="card">     
                                <img src="https://bnks.edu.np/uploads/gallery/gallery-20200317041239-397.JPG" alt="School Day 2020" class="c0139 c0145 card-img">
                                <div class="card-body">
                                        <div class="c0140 c0146 card-title">
                                                School Day 2020
                                        </div>
                                </div>
                        </div>
                </div>
        </div>
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ava/namsalingmavi/resources/views/pages/gallery.blade.php ENDPATH**/ ?>