<?php $__env->startSection('content'); ?>
<div class="team-boxed">
    <div class="container">
        <div class="intro">
            <h1 class="text-center">Our Excellent Faculty</h1>
        </div>
        <div class="row people">
            <div class="col-md-4 col-lg-3 item">
                <div class="box">
                    <?php $__currentLoopData = $principal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <img class="rounded-circle" data-bs-hover-animate="pulse" src="<?php echo e(asset('storage/images/'.$data->image)); ?>">
                    <h3 class="name"><?php echo e($data->title); ?></h3>
                    <p class="title"><?php echo $data->value; ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="col-md-4 col-lg-3 item">
                <div class="box">
                    <?php $__currentLoopData = $viceprincipal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img class="rounded-circle" data-bs-hover-animate="pulse" src="<?php echo e(asset('storage/images/'.$data->image)); ?>">
                    <h3 class="name"><?php echo e($data->title); ?></h3>
                    <p class="title"><?php echo $data->value; ?></p>    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php $__currentLoopData = $teach; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 col-lg-3 item">
                <div class="box">
                    
                    <img class="rounded-circle" data-bs-hover-animate="pulse" src="<?php echo e(asset('storage/images/'.$data->image)); ?>">
                    <h3 class="name"><?php echo e($data->title); ?></h3>
                    <p class="title"><?php echo $data->value; ?></p>  
                      
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/namsalin/public_html/namsalingmavi/resources/views/pages/aboutus/bot.blade.php ENDPATH**/ ?>