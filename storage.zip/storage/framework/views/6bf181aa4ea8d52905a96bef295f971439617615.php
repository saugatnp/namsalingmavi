<?php $__env->startSection('content'); ?>
        <div class="book-list">
                <div class="row">
                        <div class="col-sm-6 book0-10">
                                <h2 >
                                        Book List
                                </h2>
                                <div class="book-list-pdf">
                                        <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <img src="<?php echo e($img->image); ?>"
                                                frameBorder="0"
                                                scrolling="auto"
                                                height="100%"
                                                width="100%">
                                        </iframe>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                &nbsp;
                                <a href="#" class="btn btn-primary" target="_blank" rel="noopener noreferrer" margin="20px">
                                        &nbsp;
                                        <i class="fa fa-download mr-1">
                                        </i> 
                                        &nbsp;  Download
                                </a>
                        </div>
                        <div class="col-sm-4 book0-10 ">
                                <h5>Book List/Others</h5>
                                <ul class="list-group">
                                        
                                        
                                        <?php $__currentLoopData = $book; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a class="active list-group-item-action list-group-item" href="/academics/booklist/<?php echo e($data->id); ?>">
                                                <?php echo e($data->title); ?>

                                        </a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                </ul>
                        </div>
                </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/namsalingmavi/resources/views/pages/academics/booklist.blade.php ENDPATH**/ ?>