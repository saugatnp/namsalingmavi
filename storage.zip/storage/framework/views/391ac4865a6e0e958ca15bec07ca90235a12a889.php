<?php $__env->startSection('content'); ?>

    <div class="mainback">
        <h1>Gallery</h1>
        <div class="back">
            <table cellpadding="0" style="width:100%;border: 1px solid black;">
                <tr>
                    <th>S.N.</th>
                    <th>Album Name</th>
                    <th>Action</th>
                </tr>
                <?php $__currentLoopData = $album; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td></td>
                        <td><?php echo e($data->title); ?></td>
                        <td><a class="btn btn-primary " href="/index/<?php echo e($data->id); ?>/edit">
                                <i class="fa fa-edit"></i>
                                &nbsp;Edit
                            </a>
                            
                            <?php echo Form::open(['action' => ['PostController@destroy', $data->id], 'method' => 'POST', 'class' => 'pull-right ', 'onsubmit' => 'return confirm("are you sure ?")']); ?>

                            <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                            <button type="submit" id="submit" name="Delete" value="Delete"
                                class="btn btn-primary">Delete</button>
                            <?php echo Form::close(); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            
            <?php echo Form::open(['action' => 'HomeController@add', 'method' => 'POST']); ?>

            <div class="form-group">
                <?php echo e(Form::label('title', 'Add new album')); ?>

                <?php echo e(Form::text('title', '', ['class' => 'form-control', 'placeholder' => 'Add new album'])); ?>

            </div>
            <?php echo e(Form::submit('Add Album', ['class' => 'btn btn-primary'])); ?>

            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/namsalingmavi/resources/views/backends/gallery.blade.php ENDPATH**/ ?>