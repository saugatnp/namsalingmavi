<?php $__env->startSection('content'); ?>
        <div class="exam-routine">
                
                <div class="col-md-8">
                        <h1> Routine </h1>
                        <p> Lorem ipsum dolor sit amet consectetur adipisicing elit. Totam, quos placeat magni quidem autem, excepturi, aspernatur eligendi assumenda aperiam officia nihil eos consequatur illum nulla necessitatibus quam veniam! Impedit, aperiam.
                        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Libero consequatur optio distinctio id, deleniti aut ab, omnis, voluptatum maiores in at repudiandae minima deserunt doloremque illum dolores iste quos quasi.
                        </p>
                        <img src="http://sagarmatha.edu.np/uploads/content_image/routine_i_i.jpg" width="100%">
                </div>

        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ava/namsalingmavi/resources/views/pages/academics/examroutine.blade.php ENDPATH**/ ?>