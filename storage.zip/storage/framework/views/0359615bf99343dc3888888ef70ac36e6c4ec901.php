<?php $__env->startSection('content'); ?>
<div class="heading heading-icon">
  <h2>बिध्यालय ब्यावस्थापन समिति</h2>
</div>
    <section class="our-webcoderskull padding-lg">
        <div class="container">
            <ul class="row" style="padding:0;">
              <?php $__currentLoopData = $smc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class="col-12 col-md-6 col-lg-3">
                  <div class="cnt-block equal-hight" style="height: 349px;">
                    <figure><img src="<?php echo e(asset('storage/images/'.$data->image)); ?>" class="img-responsive" alt=""></figure>
                    <h3><a href="#"><?php echo e($data->title); ?></a></h3>
                    <p><?php echo $data->value; ?></p>
                    
                  </div>
              </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/namsalin/public_html/namsalingmavi/resources/views/pages/aboutus/smsc.blade.php ENDPATH**/ ?>