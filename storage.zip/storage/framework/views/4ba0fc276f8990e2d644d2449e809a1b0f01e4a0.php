<?php $__env->startSection('content'); ?>
<div >
    <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h1 style="text-align:center; margin-top:30px;"><?php echo e($data->title); ?></h1></br></br>
<center><img class="photo" src="<?php echo e($data->image); ?>"></center>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/namsalingmavi/resources/views/pages/noticedetail.blade.php ENDPATH**/ ?>